# Extended Docs

![diagram](https://www.plantuml.com/plantuml/svg/0/TOxDQWCn38JFqLCCvD1JbYRqs4D8scEWq2TGTzN5n9ONsOQ4DEzUThFqnxGw225zCwDjocov14ztU1syot2Q8numS2-9nexDQKFfw7HWup0T3cozKwplg_tpAOif-ttqqT0RdojW5wqJkvtVFBT7ejPpIjXnalqu4Ia7IGEt0fNST2M4CvPFK-52Y-OBnUF7QeKNiHIL5WUHxBH7_B6hQSmGqRNEUOyH5y9tPdCpmQIR3O5_qdy9__ZaIbG9HxneITBDGRGLxKhmdm00)

![diagram](https://www.plantuml.com/plantuml/svg/0/POv12iCW44NtSugvG2uGWaJD2Ggbwq5d8KqqrR6GsnTDeO5kPlF_lF_c8fIbRYlib2Mui5CKl1VE0EtYe52FkAH7oayW9-5DmgW1T8lCYDE4BZC9t_XLkGWgzUiP0DDwzXzXmU9m8bgmfCZWkKXE1zh-Tav_iRPlUF1yXNU9vjdu7N1Ld3dwkgqV)

Multiple markdowns can be ordered using `<name>.1.md, <name>.2.md .. <name>.<n>.md`

You can choose where to place a certain diagram by using `![name](<diagram name>.puml)`

![diagram](https://www.plantuml.com/plantuml/png/0/NKyn2iCm3DpzYjj5oD0Fn26PMaefD5CMONl8aaBiBShVYsrvgP34SJfEqX0J7yblYHdTRAXhGK3Vy0gWJSW8tFZue7BahBMAErh24RVlBaRGGafEdBY0KiiDK0tfBW56Za4rxZrFfxzK8-xrl5SV06UyvEyUjSrjpLJc-_fBymVC47PV7lq1)

Feel free to add any additional details necesary.
