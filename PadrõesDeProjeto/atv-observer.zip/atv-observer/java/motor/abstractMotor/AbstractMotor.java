package motor.abstractMotor;

import motor.Motor;
import motor.MotorState;

public abstract class AbstractMotor implements Motor
{
    protected MotorState state = null;
	
	//----------------------------------------------------
	protected AbstractMotor(MotorState state)
	{
		this.state = state;
	}
	
	//----------------------------------------------------
	public MotorState getState()
	{
		return state.clone();
	}
	
	//----------------------------------------------------
	public float getAccelerationFraction()
	{
		return state.accelerationFraction();
	}
	
	//----------------------------------------------------
	public float getRotationsPerMinute()
	{
		return state.rotationsPerMinute();
	}
	
	//----------------------------------------------------
	@Override
	public void start()
	{
		state.setCurrentStatus(MotorState.Status.ON);
		state.setAccelerationFraction(0.1f);
		state.setRotationsPerMinute(determineRotationsPerMinute());
	}

	//----------------------------------------------------
	@Override
	public void stop()
	{
		state.setCurrentStatus(MotorState.Status.OFF);
		state.setAccelerationFraction(0.0f);
		state.setRotationsPerMinute(0.0f);
	}
	
	
	//----------------------------------------------------
	@Override
	public void speedUp(final float percent)
	{
		if (isOff()) return;
        adjustSpeed(Math.abs(percent), true);
	}
	
	//----------------------------------------------------
	@Override
	public void slowDown(float percent)
	{
		 if (isOff()) return;
	     adjustSpeed(Math.abs(percent), false);
	}
	
	//----------------------------------------------------
	@Override
	public boolean isOn()
	{
		return state.currentStatus() == MotorState.Status.ON;
	}

	//----------------------------------------------------
	@Override
	public boolean isOff()
	{
		return state.currentStatus() == MotorState.Status.OFF;
	}
	
	//----------------------------------------------------
	public abstract float getPower();
	protected abstract float determineRotationsPerMinute();
	
    private void adjustSpeed(float percent, boolean increase) {
        if (increase) {
            float newAccelerationFraction = state.accelerationFraction() + 
                (1 - state.accelerationFraction()) * percent;
            state.setAccelerationFraction(newAccelerationFraction);
        } else {
            float base = (float) Math.pow((Math.exp(-state.accelerationFraction()) / 2.72), 2);
            float newAccelerationFraction = state.accelerationFraction() - 
                state.accelerationFraction() * base * percent;
            state.setAccelerationFraction(newAccelerationFraction);
        }
        state.setRotationsPerMinute(determineRotationsPerMinute());
    }
}
