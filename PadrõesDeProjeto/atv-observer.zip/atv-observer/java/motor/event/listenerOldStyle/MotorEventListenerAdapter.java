package motor.event.listenerOldStyle;

import motor.event.MotorEvent;

public class MotorEventListenerAdapter implements MotorEventListener {

	@Override
	public void beforeStart(MotorEvent me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterStart(MotorEvent me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforeStop(MotorEvent me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterStop(MotorEvent me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforeSlowDown(MotorEvent me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterSlowDown(MotorEvent me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforeSpeedUp(MotorEvent me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterSpeedUp(MotorEvent me) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
