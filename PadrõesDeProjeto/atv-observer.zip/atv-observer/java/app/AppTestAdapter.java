package app;

import fusca.motor.Motor1500;
import motor.Motor;
import motor.MotorState;
import motor.event.MotorEvent;
import motor.event.listenerOldStyle.MotorEventListener;
import motor.event.listenerOldStyle.MotorEventListenerAdapter;
import motor.observable.ObservableMotor;

public class AppTestAdapter {
	
	ObservableMotor motor = null;
	
	// -------------------------------------------------------------------------------------
	MotorEventListener speedMotorLister = new MotorEventListenerAdapter() 
	{
		@Override
		public void beforeSpeedUp(MotorEvent me) 
		{
			System.out.println(" before speed up " + MotorState.stringfy(me.state));
		}
		@Override
		public void afterSpeedUp(MotorEvent me) 
		{
			System.out.println(" after speed up " + MotorState.stringfy(me.state));
		}
	};
	
	// -------------------------------------------------------------------------------------
	MotorEventListener stopMotorLister = new MotorEventListenerAdapter() 
	{
		@Override
		public void beforeStop(MotorEvent me) 
		{
			System.out.println(" before stop " + MotorState.stringfy(me.state));
		}
		@Override
		public void afterStop(MotorEvent me) 
		{
			System.out.println(" after stop " + MotorState.stringfy(me.state));
		}
	};
	
	
	// -------------------------------------------------------------------------------------
	public AppTestAdapter() 
	{
		Motor motor1500 = new Motor1500();
		this.motor = new ObservableMotor(motor1500);
	}
	
	// -------------------------------------------------------------------------------------
	public static void main(String[] args) 
	{
		
		AppTestAdapter app = new AppTestAdapter();
		
		app.motor.addMotorListener(app.speedMotorLister);
		app.motor.addMotorListener(app.stopMotorLister);
		
		app.motor.start();
		app.motor.speedUp(0.5f);
		app.motor.stop();
	}
}
