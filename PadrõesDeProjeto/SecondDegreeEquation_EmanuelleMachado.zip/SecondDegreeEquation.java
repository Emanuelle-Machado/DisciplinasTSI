package designPatterns;

public class SecondDegreeEquation {

	private float a;
	private float b;
	private float c;
	
	// --------------------------------------------------------------------
	public SecondDegreeEquation(float a,float b,float c) 
	{
		this.a = a;
		this.b = b;
		this.c = c;
		
		if(Math.abs(0.0f - a) <= 0.000_000_000_1)
			throw new InvalidSecondDegreeEquationException("Invalid parameter 'a' " + a);
	}

	// --------------------------------------------------------------------
	public final float getA() 
	{
		return a;
	}

	public final float getB() 
	{
		return b;
	}

	public final float getC() 
	{
		return c;
	}
	
	// --------------------------------------------------------------------
	public float calculateDelta() 
	{
		float delta = b*b - 4*a*c;
		
		return delta;
	}

	// --------------------------------------------------------------------
	public boolean hasRealSolution() 
	{
		float delta = calculateDelta();		
		
		if(delta < 0) 
			return false;
		
		return true;
	}

	// --------------------------------------------------------------------
	public int howManyRealSolutions() 
	{
		float delta = calculateDelta();	

		if (delta == 0) 
		{
			return 1;
		} 
		else if (delta > 0) 
		{
			return 2;
		}
		return 0;
	}

	// --------------------------------------------------------------------
	public float[] getRealSolutions() {
		float delta = calculateDelta();

		if (delta < 0) {
			return new float[0];

		} else if (delta == 0) {
			float x = -b / (2 * a);
			return new float[] { x };
		} else {
			float sqrtDelta = (float) Math.sqrt(delta);
			float x1 = (-b + sqrtDelta) / (2 * a);
			float x2 = (-b - sqrtDelta) / (2 * a);
			return new float[] { x1, x2 };
		}
	}
	
}
