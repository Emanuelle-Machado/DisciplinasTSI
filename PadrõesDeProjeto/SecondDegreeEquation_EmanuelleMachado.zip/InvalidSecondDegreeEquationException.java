package designPatterns;

public class InvalidSecondDegreeEquationException extends RuntimeException {

	
	
	public InvalidSecondDegreeEquationException(String msg) 
	{
		super(msg);
	}

	
	
}
