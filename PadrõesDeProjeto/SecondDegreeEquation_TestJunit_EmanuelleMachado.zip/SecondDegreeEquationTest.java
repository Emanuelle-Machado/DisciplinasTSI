package designPatterns;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SecondDegreeEquationTest {

	@Test
	void shouldInstantiateCorrectly() 
	{
		float a = 1.0f;
		float b = 2.0f;
		float c = 3.0f;

		SecondDegreeEquation equation = new SecondDegreeEquation(a, b, c);	
			
		float obtained;
		float maxDifference = 0.000_000_000_1f;

		obtained = equation.getA();
		assertTrue( Math.abs ( a - obtained ) <= maxDifference);

		obtained = equation.getB();
		assertTrue( Math.abs ( b - obtained ) <= maxDifference);

		obtained = equation.getC();
		assertTrue( Math.abs ( c - obtained ) <= maxDifference);
	}
	
	@Test
	void shouldThrowsExceptionWithAndInvalidEquation() 
	{
		float a = 0f;
		float b = 2f;
		float c = 3f;

		assertThrows(InvalidSecondDegreeEquationException.class, ()->{
			new SecondDegreeEquation(a, b, c);	
		});
	}
	
	@Test
	void shouldReturnTrueOrFalseAsEquationHasRealSolution() 
	{
		SecondDegreeEquation eq;
		
		float a;
		float b;
		float c;
		
		// -------------------------------------
		a = 2;
		b = 2;
		c = 3;
		eq = new SecondDegreeEquation(a, b, c);

		boolean expected = false;
		boolean obtained = eq.hasRealSolution();
		assertEquals(expected, obtained);

		// -------------------------------------
		a = 2;
		b = 2;
		c = -3;
		eq = new SecondDegreeEquation(a, b, c);

		expected = true;
		obtained = eq.hasRealSolution();
		assertEquals(expected, obtained);

		// -------------------------------------
		a = -2;
		b = 2;
		c = 3;
		eq = new SecondDegreeEquation(a, b, c);

		expected = true;
		obtained = eq.hasRealSolution();
		assertEquals(expected, obtained);
		
		// -------------------------------------
		a = 2;
		b = 4;
		c = 3;
		eq = new SecondDegreeEquation(a, b, c);

		expected = false;
		obtained = eq.hasRealSolution();
		assertEquals(expected, obtained);

		// -------------------------------------
		a = 2;
		b = -4;
		c = -3;
		eq = new SecondDegreeEquation(a, b, c);

		expected = true;
		obtained = eq.hasRealSolution();
		assertEquals(expected, obtained);
		
		//-------------------------------------
		a = -2;
		b = 4;
		c = 3;
		eq = new SecondDegreeEquation(a, b, c);
		//
		expected = true;
		obtained = eq.hasRealSolution();
		assertEquals(expected, obtained);
		
		// -------------------------------------
		a = 2;
		b = 0;
		c = -3;
		eq = new SecondDegreeEquation(a, b, c);

		expected = true;
		obtained = eq.hasRealSolution();
		assertEquals(expected, obtained);
		
		// -------------------------------------
		a = -2;
		b = 2;
		c = 0;
		eq = new SecondDegreeEquation(a, b, c);

		expected = true;
		obtained = eq.hasRealSolution();
		assertEquals(expected, obtained);
	}
	
	
	@Test
	void shouldAssertNumberOfRealSolutions() {

		SecondDegreeEquation equation;

		float a;
		float b;
		float c;

		// --------------------------------------------

		a = 2;
		b = 2;
		c = 3;
		equation = new SecondDegreeEquation(a, b, c);

		int numberOfRealSolutions = 0;
		int obtained = equation.howManyRealSolutions();
		assertEquals(0, obtained);

		// --------------------------------------------

		a = 2;
		b = 2;
		c = -3;
		equation = new SecondDegreeEquation(a, b, c);

		numberOfRealSolutions = 2;
		obtained = equation.howManyRealSolutions();
		assertEquals(numberOfRealSolutions, obtained);

		// --------------------------------------------

		a = -2;
		b = 2;
		c = 3;
		equation = new SecondDegreeEquation(a, b, c);

		numberOfRealSolutions = 2;
		obtained = equation.howManyRealSolutions();
		assertEquals(numberOfRealSolutions, obtained);

		// --------------------------------------------

		a = 2;
		b = 4;
		c = 3;
		equation = new SecondDegreeEquation(a, b, c);

		numberOfRealSolutions = 0;
		obtained = equation.howManyRealSolutions();
		assertEquals(numberOfRealSolutions, obtained);

		// --------------------------------------------

		a = 2;
		b = -4;
		c = -3;
		equation = new SecondDegreeEquation(a, b, c);

		numberOfRealSolutions = 2;
		obtained = equation.howManyRealSolutions();
		assertEquals(numberOfRealSolutions, obtained);

		// --------------------------------------------

		a = -2;
		b = 4;
		c = 3;
		equation = new SecondDegreeEquation(a, b, c);

		numberOfRealSolutions = 2;
		obtained = equation.howManyRealSolutions();
		assertEquals(numberOfRealSolutions, obtained);
	}
	
	void shouldAssertEquationRealSolution() {
		
		SecondDegreeEquation equation;

		float a;
		float b;
		float c;

		float[] expected = { 2, 1 };
		float[] obtained;
		
		// --------------------------------------------
		a = 2;
		b = 2;
		c = 3;

		equation = new SecondDegreeEquation(a, b, c);
		expected = new float[0];
		obtained = equation.getRealSolutions();
		assertArrayEquals(expected, obtained, 0.001f);

		// --------------------------------------------
		a = 2;
		b = 2;
		c = -3;
		
		equation = new SecondDegreeEquation(a, b, c);
		expected = new float[] {0.8f, -1.8f};
		obtained = equation.getRealSolutions();
		assertArrayEquals(expected, obtained, 0.001f);

		// --------------------------------------------
		a = -2;
		b = 2;
		c = 3;
		
		equation = new SecondDegreeEquation(a, b, c);
		expected = new float[] {-0.8f, 1.8f};
		obtained = equation.getRealSolutions();
		assertArrayEquals(expected, obtained, 0.001f);
		// --------------------------------------------
		a = 2;
		b = 4;
		c = 3;

		equation = new SecondDegreeEquation(a, b, c);
		expected = new float[0];
		obtained = equation.getRealSolutions();
		assertArrayEquals(expected, obtained, 0.001f);
				
		// --------------------------------------------
		a = 2;
		b = -4;
		c = -3;
		
		equation = new SecondDegreeEquation(a, b, c);
		expected = new float[] {2.5f, -0.5f};
		obtained = equation.getRealSolutions();
		assertArrayEquals(expected, obtained, 0.001f);

		// --------------------------------------------
		a = -2;
		b = 4;
		c = 3;
		
		equation = new SecondDegreeEquation(a, b, c);
		expected = new float[] {-0.5f, 2.5f};
		obtained = equation.getRealSolutions();
		assertArrayEquals(expected, obtained, 0.001f);
        
		
	}

}
