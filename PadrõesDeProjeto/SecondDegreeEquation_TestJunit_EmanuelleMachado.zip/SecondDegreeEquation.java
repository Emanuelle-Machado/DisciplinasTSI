package designPatterns;

public class SecondDegreeEquation {

	private float a;
	private float b;
	private float c;
	
	// --------------------------------------------------------------------
	public SecondDegreeEquation(float a,float b,float c) 
	{
		this.a = a;
		this.b = b;
		this.c = c;
		
		if(Math.abs(0.0f - a) <= 0.000_000_000_1)
			throw new InvalidSecondDegreeEquationException("Invalid parameter 'a' " + a);
	}

	// --------------------------------------------------------------------
	public final float getA() 
	{
		return a;
	}

	public final float getB() 
	{
		return b;
	}

	public final float getC() 
	{
		return c;
	}
	
	// --------------------------------------------------------------------
	public float calculateDelta() 
	{
		float delta = b*b - 4*a*c;
		
		return delta;
	}

	// --------------------------------------------------------------------
	public boolean hasRealSolution() 
	{
		float delta = calculateDelta();		
		
		if(delta < 0) 
			return false;
		
		return true;
	}

	// --------------------------------------------------------------------
	public int howManyRealSolutions() 
	{
		float delta = calculateDelta();	

		if (delta == 0) 
		{
			return 1;
		} 
		else if (delta > 0) 
		{
			return 2;
		}
		return 0;
	}

	// --------------------------------------------------------------------
	public float[] getRealSolutions() 
	{
		float delta = calculateDelta();	
		
        if (delta > 0) 
        {
            double x1 = (-b + Math.sqrt(delta)) / (2 * a);
            double x2 = (-b - Math.sqrt(delta)) / (2 * a);
            
            return new float[]{(float) x1, (float) x2};
        } 
        else if (delta == 0) 
        {
            double x = -b / (2 * a);
            
            return new float[]{(float) x};
        }
        return new float[0];
	}
	
}
