package arithmeticProgression;


public class App {

	private ArithmeticProgression pA = null;
	private TextUserInterface textUserInterface = new TextUserInterface();
	
	// --------------------------------------------------------------------
	public void createArithmeticProgression() 
	{
		int firstTerm = this.textUserInterface.readFirstTerm();
		int ratio = this.textUserInterface.readRatio();
		this.pA = new ArithmeticProgression(firstTerm, ratio);
	}
	
	// --------------------------------------------------------------------
	public void printArithmeticProgressionData() 
	{
		int numberOfTerms = textUserInterface.readNumberOfTerms();
		
		int[] sequence = pA.sequence(numberOfTerms);
		int sum = pA.sumOfAllTerms(numberOfTerms);
		
		textUserInterface.printTerms(sequence);
		textUserInterface.printSumOfTerms(numberOfTerms, sum);
	}

	// --------------------------------------------------------------------
	static public void main(String[] args) {
		App app = new App();
		app.createArithmeticProgression();
		app.printArithmeticProgressionData();
	}

}
