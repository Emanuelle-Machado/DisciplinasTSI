package builder;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

class PersonBuilderTest {

	String    firstName              = "Vilson";
	String    midleName              = "Luiz";
	String    lastName               = "Dalle Mole";
	String    gender                 = "M";
	String    motherFullName         = "Maria"; 
	String    fatherFullName         = "José";
	LocalDate birthDate              = LocalDate.MIN;
	float     heightInCentimeters    = Float.NaN;
	float     weightInKilograms      = Float.NaN;
	String    ethnicity              = "Brazilian";
	String    specialCharacteristics = "Teaches";
	
	private Person partialWithFullName() {

		return new PersonBuilder()
				.firstName(firstName)
				.midleName(midleName)
				.lastName(lastName)
				.build();
	}

	//----------------------------------------------------------------
	private Person completePerson() 
	{
		return new PersonBuilder()
			.firstName(firstName)
			.midleName(midleName)
			.lastName(lastName)
			.gender(gender)
			.motherFullName(motherFullName)
			.fatherFullName(fatherFullName)
			.birthDate(birthDate)
			.heightInCentimeters(heightInCentimeters)
			.weightInKilograms(weightInKilograms)
			.ethnicity(ethnicity)
			.specialCharacteristics(specialCharacteristics)
			.build();
	}
	
	//----------------------------------------------------------------
	@Test
	public void shouldCreatePartialObject() 
	{
		Person person = partialWithFullName();
		
		assertTrue(firstName.equals(person.getFirstName()));
		assertTrue(midleName.equals(person.getMidleName()));
		assertTrue(lastName.equals(person.getLastName()));
	}
	
	//----------------------------------------------------------------
	@Test
	public void shouldCreateFullObject() 
	{
		Person person = completePerson();
		 
		assertTrue(firstName.equals(person.getFirstName()));
		assertTrue(midleName.equals(person.getMidleName()));
		assertTrue(lastName.equals(person.getLastName()));
		assertTrue(gender.equals(person.getGender()));
		assertTrue(motherFullName.equals(person.getMotherFullName()));
		assertTrue(fatherFullName.equals(person.getFatherFullName()));
		assertTrue(birthDate.equals(person.getBirthDate()));
		assertEquals(heightInCentimeters, person.getHeightInCentimeters());
		assertEquals(weightInKilograms, person.getWeightInKilograms());
		assertTrue(ethnicity.equals(person.getEthnicity()));
		assertTrue(specialCharacteristics.equals(person.getSpecialCharacteristics()));
	}
	

}
