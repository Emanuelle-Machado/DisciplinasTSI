package builder;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PersonTest {

	final String firstName = "Vilson";
    final String midleName = "Luiz";
    final String lastName = "Dalle Mole";

    private Person partialWithFullName() 
    {
        Person person = new Person();
        person.setFirstName(firstName);
        person.setMidleName(midleName);
        person.setLastName(lastName);

        return person;
    }

    @Test
    void shouldReturnCorrectFullName()
    {
        String fullName = firstName + " " + midleName + " " + lastName;

        assertTrue(fullName.equals(partialWithFullName().getFullName()));
    }

    @Test
    void shouldReturnCorrectFullNameWithoutMidleName()
    {
        String fullName = firstName + " " + lastName;
        Person person = partialWithFullName();

        person.setMidleName("");
        assertTrue(fullName.equals(person.getFullName()));

        person.setMidleName(null);
        assertTrue(fullName.equals(person.getFullName()));
    }

}